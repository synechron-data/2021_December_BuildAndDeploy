// Constructor Function
const Person = (function(){
    function Person(name, age) {
        this._name = name;
        this._age = age;
    }
    
    Person.prototype.getName = function () {
        return this._name;
    }
    
    Person.prototype.setName = function (value) {
        this._name = value;
    }

    Person.prototype.getAge = function () {
        return this._age;
    }
    
    Person.prototype.setAge = function (value) {
        this._age = value;
    }

    return Person;
})();

var p1 = new Person("Manish", 10);
console.log(p1.getName());
console.log(p1.getAge());

p1.setName("Abhijeet");
p1.setAge(20);

console.log(p1.getName());
console.log(p1.getAge());

console.log("\n");
var p2 = new Person("Subodh", 20);
console.log(p2.getName());
console.log(p2.getAge());

p2.setName("Ramakant");
p2.setAge(30);

console.log(p2.getName());
console.log(p2.getAge());

console.log(p1);
console.log(p2);

// 104 bytes