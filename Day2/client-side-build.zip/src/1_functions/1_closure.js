'use strict'

const counter = (function () {
    var count = 0;

    function next() {
        return count += 1;
    }

    function prev() {
        return count -= 1;
    }

    // return {
    //     next: next,
    //     prev: prev
    // };

    return { next, prev };
}());

setInterval(() => {
    console.log(counter.next());
}, 2000);

setInterval(() => {
    console.log(counter.prev());
}, 5000);