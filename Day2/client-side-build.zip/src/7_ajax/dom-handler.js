import postApiClient from "./post-api-client";

window.addEventListener("load", () => {
    const ajaxDiv = document.querySelector("#ajaxDiv");

    if (ajaxDiv.style.display === "none") {
        ajaxDiv.style.display = "block";
    }

    const button = document.createElement("button");
    button.className = "btn btn-primary";
    button.innerText = "Get Data";

    const btnArea = document.querySelector("#btnArea");
    btnArea.appendChild(button);

    // button.addEventListener("click", function () {
    //     // alert("Button was clicked...");
    //     var data = [
    //         { id: 1, title: "check", body: "check" },
    //         { id: 2, title: "check2", body: "check2" }
    //     ];
    //     generateTable(data);
    // });

    // // 1. Using Callbacks
    // button.addEventListener("click", function () {
    //     postApiClient.getAllPostsUsingCallbacks((data) => {
    //         generateTable(data);
    //     }, (eMsg) => {
    //         console.error(eMsg);
    //     });
    // });

    // // 2. Using Promise
    // button.addEventListener("click", function () {
    //     postApiClient.getAllPostsUsingPromise().then((data) => {
    //         generateTable(data);
    //     }, (eMsg) => {
    //         console.error(eMsg);
    //     });
    // });

    // 3. Using Async Await
    // button.addEventListener("click", async function () {
    //     try {
    //         var data = await postApiClient.getAllPostsUsingPromise();
    //         generateTable(data);
    //     } catch (eMsg) {
    //         console.error(eMsg);
    //     }
    // });

    // // 4. Using Async Function
    // button.addEventListener("click", async function () {
    //     try {
    //         var data = await postApiClient.getAllPostsAsync();
    //         generateTable(data);
    //     } catch (eMsg) {
    //         console.error(eMsg);
    //     }
    // });

    // 5. Using Async Generators
    button.addEventListener("click", async function () {
        const it = postApiClient.getAllPosts();

        it.next().then(({ value, done }) => {
            generateTable(value);
        }).catch((eMsg) => {
            console.error(eMsg);
        })
    });

    function generateTable(data) {
        const table_body = document.querySelector("#postTableBody");
        let row, cell;

        for (const item of data) {
            row = table_body.insertRow();
            cell = row.insertCell();
            cell.textContent = item.id;
            cell = row.insertCell();
            cell.textContent = item.title;
            cell = row.insertCell();
            cell.textContent = item.body;
        }
    }
});