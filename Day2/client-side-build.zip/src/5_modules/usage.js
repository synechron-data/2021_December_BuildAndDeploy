// Case 1- Default Import
// import square from './lib';
// console.log("Square:", square(20));

// import sqr from './lib';
// console.log("Square:", sqr(20));

// import * as l from './lib';
// console.log("Square:", l.default(20));

// Case 2 - Named Imports - Multiple Imports
// import { square, check } from './lib';
// console.log("Square: ", square(20));
// console.log("Check: ", check(20));

// import { square as sqr, check as chk } from './lib';
// console.log("Square: ", sqr(20));
// console.log("Check: ", chk(20));

// import * as l from './lib';
// console.log("Square: ", l.square(20));
// console.log("Check: ", l.check(20));

// Case 3 - Default and Named Imports 
// import square, { check } from "./lib";
// console.log("Square: ", square(20));
// console.log("Check: ", check(20));

// import sqr, { check as chk } from "./lib";
// console.log("Square: ", sqr(20));
// console.log("Check: ", chk(20));

// import * as l from './lib';
// console.log("Square:", l.default(20));
// console.log("Check: ", l.check(20));

// Import and instantiate Person Class in this file 
import Person from './lib';

var p1 = new Person("Manish", 10);
console.log(p1.getName());
console.log(p1.getAge());

p1.setName("Abhijeet");
p1.setAge(20);

console.log(p1.getName());
console.log(p1.getAge());