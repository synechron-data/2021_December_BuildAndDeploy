// var employees = new Array();
// console.log(employees);
// console.log(typeof employees);

// var employees = [];
// console.log(employees);
// console.log(typeof employees);

// var employees = new Array(2);               // Initial Length

// employees.push("Manish");
// employees.unshift("Abhijeet");

// employees[1] = "Abhishek";
// employees.splice(2, 1, "Neeraj");

// console.log(employees);
// console.log(employees.length);

// var employees = new Array("Manish", "Abhijeet");
// var employees = new Array(10, 20);
// console.log(employees);
// console.log(employees.length);

// var employees = new Array("Manish");
// var employees = new Array(10);
// var employees = Array.of(10);
// console.log(employees);
// console.log(employees.length);

// var arr = [10, 20, 30, 40, 50];
// // var employees = new Array(arr);
// // var employees = Array.from(arr);
// var employees = [...arr];
// console.log(employees);
// console.log(employees.length);

// -------------------------------------------------  Iterate

var employees = [
    { id: 1, name: "Manish" },
    { id: 2, name: "Varun" },
    { id: 3, name: "Paresh" },
    { id: 4, name: "Devesh" },
    { id: 5, name: "Atul" },
    { id: 6, name: "Abhishek" }
];

// for (let i = 0; i < employees.length; i++) {
//     console.log(`${i}       ${JSON.stringify(employees[i])}`);
// }

// for (const i in employees) {
//     console.log(`${i}       ${JSON.stringify(employees[i])}`);
// }

// ECMASCRIPT 2015 - for-of loop
// for (const item of employees) {
//     console.log(`${JSON.stringify(item)}`);
// }

// for (const [index, item] of employees.entries()) {
//     console.log(`${index}           ${JSON.stringify(item)}`);
// }

// Create a new Array with all the Names in uppercase from employees (Transformation)
// 1. Named Function
// function mappingFn(employee) {
//     return employee.name.toUpperCase();
// }

// var names1 = employees.map(mappingFn);
// console.log(names1);

// // 2. Anonymous Function
// var names2 = employees.map(function (employee) {
//     return employee.name.toUpperCase();
// });
// console.log(names2);

// // 3. Multiline Function
// var names3 = employees.map((employee) => {
//     return employee.name.toUpperCase();
// });
// console.log(names3);

// // 4. Singleline Function
// var names4 = employees.map((employee) => employee.name.toUpperCase());
// console.log(names4);

var ids = employees.map(employee => employee.id);
console.log(ids);

// Write a code which will add all numbers in the ids array (Sum of all ids)
var sum = ids.reduce((pvalue, acc) => pvalue + acc);
console.log(sum);

var anames = employees.filter(employee=>employee.name.startsWith('A'));
console.log(anames);
