// var result = 10 * "abc";
// console.log(result);

// T && T = T
// T && F = F
// F && T = F

// console.log(true && "abc");
// console.log(false && "abc");

// console.log(true ? "abc" : "xyz");
// console.log(false ? "abc" : "xyz");

// console.log(true && "abc" || "xyz");
// console.log(false && "abc" || "xyz");

// var obj = null;
// var obj = undefined;
// var obj = { id: 1 };

// if ((obj == null) || (obj == undefined)) {
//     console.log("object is null or undefined");
// } else {
//     console.log("object is:", obj);
// }

// if (!obj) {
//     console.log("object is null or undefined");
// } else {
//     console.log("object is:", obj);
// }

// ---------------------------------------------------------

// let a = 10;
// let b = "10";

// console.log(typeof a);
// console.log(typeof b);

// console.log(a == b);        // Abstract Equality
// console.log(a === b);        // Strict Equality

let a = { id: 0 };
let b = { id: 0 };
let c = b;

console.log(a == b);        // Abstract Equality
console.log(a === b);        // Strict Equality

console.log(b == c);        // Abstract Equality
console.log(b === c);        // Strict Equality