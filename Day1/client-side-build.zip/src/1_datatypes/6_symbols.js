// const color = "red";

// // This function should give true only if, color constant is passed in the function
// function isRedColor(str) {
//     console.log(str === color);
// }

// isRedColor(color);
// isRedColor("red");

// var clr = "red";
// isRedColor(clr);

// -----------------------------------

// const color = { code: "red" };

// // This function should give true only if, color constant is passed in the function
// function isRedColor(str) {
//     console.log(str === color);
// }

// isRedColor(color);
// isRedColor({ code: "red" });

// var clr = { code: "red" };
// isRedColor(clr);

// ----------------------------------- Symbol (Unique Immutables)

const color = Symbol("red");

// This function should give true only if, color constant is passed in the function
function isRedColor(str) {
    console.log(str === color);
}

isRedColor(color);
isRedColor(Symbol("red"));

var clr = Symbol("red");
isRedColor(clr);
