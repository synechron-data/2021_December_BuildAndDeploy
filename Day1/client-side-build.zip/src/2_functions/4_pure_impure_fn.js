// var arr = [10, 20, 30];

// Impure Function
// function append(dataArr, item) {
//     dataArr[dataArr.length] = item;
//     return dataArr;
// }

// Pure Function
// function append(dataArr, item) {
//     var rArr = [...dataArr];
//     rArr[rArr.length] = item;
//     return rArr;
// }

// var newArr1 = append(arr, 100);
// console.log(newArr1);           // Expected - [10, 20, 30, 100]

// var newArr2 = append(arr, 100);
// console.log(newArr2);           // Expected - [10, 20, 30, 100]

// Assignment ---------------------------------------------------------------------------------------------

var employees = ["Akshay", "Basavaraj", "Bhavya", "Bibhu", "Chethan", "Chhavi"];

function filter(dataArr, x) {
    var result = [];

    for (const name of dataArr) {
        // if (name[0] === x) {
        //     result.push(name);
        // }

        // if (name.charAt(0) === x) {
        //     result.push(name);
        // }

        if (name.startsWith(x)) {
            result.push(name);
        }
    }

    return result;
}

var result1 = filter(employees, 'A');
console.log(result1);                   // ["Akshay"];

var result2 = filter(employees, 'B');
console.log(result2);                   // ["Basavaraj", "Bhavya", "Bibhu"];

var result3 = filter(employees, 'C');
console.log(result3);                   // ["Chethan", "Chhavi"];

console.log(employees);                 // ["Akshay", "Basavaraj", "Bhavya", "Bibhu", "Chethan", "Chhavi"];