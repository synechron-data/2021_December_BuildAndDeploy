// function hello() {
//     console.log("Hello World!");
// }

// hello();

(function () {
    console.log("Hello World!");
})();

(function () {
    console.log("Hello World!");
}());

(() => {
    console.log("Arrow - Hello World!");
})();