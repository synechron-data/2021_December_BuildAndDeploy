import React, { useContext } from 'react';
import CounterContextProvider, { CounterContext } from '../../context/CounterContextUsingHooks';

const Counter = (props) => {
    const [count, setCount] = useContext(CounterContext);

    return (
        <React.Fragment>
            <div className="text-center">
                <h3 className="text-info">Counter Component</h3>
            </div>
            <div className="d-grid gap-2 mx-auto col-6">
                <input type="text" value={count} className="form-control form-control-lg" readOnly />
                <button className="btn btn-info" onClick={() => { setCount(count + props.interval); }}>
                    <span className='fs-4'>+</span>
                </button>
                <button className="btn btn-info" onClick={() => { setCount(count - props.interval); }}>
                    <span className='fs-4'>-</span>
                </button>
            </div>
        </React.Fragment>
    );
}

Counter.defaultProps = {
    interval: 1
};

const CounterSibling = () => {
    const [count] = useContext(CounterContext);

    return (
        <>
            <div className="text-center">
                <h3 className="text-info">Counter Sibling Component</h3>
                <h3>Current Count is: {count}</h3>
            </div>
        </>
    );
}

const SiblingCommunicationUsingHooks = () => {
    return (
        <div className='mt-5'>
            <CounterContextProvider>
                <Counter />
                <hr />
                <CounterSibling />
            </CounterContextProvider>
        </div>
    );
};

export default SiblingCommunicationUsingHooks;