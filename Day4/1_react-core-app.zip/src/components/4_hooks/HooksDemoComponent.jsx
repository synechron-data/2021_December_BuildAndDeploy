import React, { Component, useState } from 'react';

class CounterUsingClass extends Component {
    constructor(props) {
        super(props);
        this._clickCount = 0;
        this.state = { count: 0 };
        this._inc = this._inc.bind(this);
        this._dec = this._dec.bind(this);
    }

    _inc(e) {
        this.setState({ count: this.state.count + 1 });
    }

    _dec(e) {
        this.setState({ count: this.state.count - 1 });
    }

    render() {
        return (
            <React.Fragment>
                <div className="text-center">
                    <h3 className="text-info">Using Class Syntax</h3>
                </div>
                <div className="d-grid gap-2 mx-auto col-6">
                    <input type="text" className="form-control form-control-lg" value={this.state.count} readOnly />
                    <button className="btn btn-info"
                        onClick={this._inc}>
                        <span className='fs-4'>+</span>
                    </button>
                    <button className="btn btn-info"
                        onClick={this._dec}>
                        <span className='fs-4'>-</span>
                    </button>
                </div>
            </React.Fragment>
        );
    }
}

const CounterUsingFunction = () => {
    // const obj = useState();
    // console.log(obj);

    const [count, setCount] = useState(0);

    return (
        <React.Fragment>
            <div className="text-center">
                <h3 className="text-info">Using Function Syntax</h3>
            </div>
            <div className="d-grid gap-2 mx-auto col-6">
                <input type="text" className="form-control form-control-lg" value={count} readOnly />
                <button className="btn btn-info" onClick={() => { setCount(count + 1); }}>
                    <span className='fs-4'>+</span>
                </button>
                <button className="btn btn-info" onClick={() => { setCount(count - 1); }}>
                    <span className='fs-4'>-</span>
                </button>
            </div>
        </React.Fragment>
    );
}

const HooksDemoComponent = () => {
    return (
        <div className='mt-5'>
            <CounterUsingClass />
            <hr />
            <CounterUsingFunction />
        </div>
    );
};

export default HooksDemoComponent;