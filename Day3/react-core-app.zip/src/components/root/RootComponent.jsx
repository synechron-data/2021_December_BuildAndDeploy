/* eslint-disable */
import React from 'react';

// import ComponentOne from '../2_multi-components/ComponentOne';
// import ComponentTwo from '../2_multi-components/ComponentTwo';

// import ComponentOne from '../3_component-with-css/ComponentOne';
// import ComponentTwo from '../3_component-with-css/ComponentTwo';

// import ComponentOne from '../4_external-css/comp-one/ComponentOne';
// import ComponentTwo from '../4_external-css/comp-two/ComponentTwo';

import ComponentOne from '../5_css-modules/comp-one/ComponentOne';
import ComponentTwo from '../5_css-modules/comp-two/ComponentTwo';
import ComponentWithState from '../6_comp-state/ComponentWithState';
import ComponentWithProps from '../7_comp-props/ComponentWithProps';
import ComponentWithBehaviour from '../8_comp-methods/ComponentWithBehaviour';
import ClassVsFuntionalComponent from '../9_class-vs-function/ClassVsFuntionalComponent';
import PropTypesComponent from '../10_prop-types/PropTypesComponent';
import LCDemoComponent from '../11_life-cycle-demo/LCDemoComponent';
import EventComponent from '../12_synthetic-event/EventComponent';
import ControlledVsUncontrolledComponent from '../13_controlled-vs-uncontrolled/ControlledVsUncontrolledComponent';
import ListRoot from '../14_list/ListComponent';
import CalculatorAssignment from '../15_assignments/CalculatorAssignment';
import CounterAssignment from '../15_assignments/CounterAssignment';

const RootComponent = () => {
    return (
        <div className='container'>
            {/* <ComponentOne />
            <ComponentTwo /> */}
            {/* <ComponentWithState /> */}
            {/* <ComponentWithProps id={1} name={"Manish"} address={{ city: "Pune" }}
                display={() => { alert("From Root"); }} /> */}
            {/* <ComponentWithBehaviour /> */}
            {/* <ClassVsFuntionalComponent /> */}
            {/* <PropTypesComponent /> */}
            {/* <LCDemoComponent /> */}
            {/* <EventComponent /> */}
            {/* <ControlledVsUncontrolledComponent /> */}
            {/* <ListRoot /> */}
            <CalculatorAssignment />
            <hr />
            <CounterAssignment />
        </div>
    );
};

export default RootComponent;