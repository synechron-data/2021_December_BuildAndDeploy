import React, { Component } from 'react';

class Counter extends Component {
    render() {
        return (
            <React.Fragment>
                <div className="text-center">
                    <h3 className="text-info">Counter Component</h3>
                </div>
                <div className="d-grid gap-2 mx-auto col-6">
                    <input type="text" className="form-control" />
                        <button className="btn btn-info">+</button>
                        <button className="btn btn-info">-</button>
                        <button className="btn btn-info">Reset</button>
                </div>
            </React.Fragment>
        );
    }
}

class CounterAssignment extends Component {
    render() {
        return (
            <div>
                <Counter />
                <br />
                <Counter interval={10} />
            </div>
        );
    }
}

export default CounterAssignment;