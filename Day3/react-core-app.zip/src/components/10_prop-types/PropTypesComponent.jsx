// import React, { Component } from 'react';

// class DemoComponent extends Component {
//     render() {
//         return (
//             <div>
//                 <h2 className="text-info">Hello, {this.props.name}</h2>
//                 <h2 className="text-info">Age, {this.props.age}</h2>
//             </div>
//         );
//     }

//     static get defaultProps() {
//         return {
//             name: "Not Given",
//             age: 0
//         };
//     }
// }

// const PropTypesComponent = () => {
//     return (
//         <div>
//             <DemoComponent />
//             <DemoComponent name={"Manish"}/>
//             <DemoComponent name={"Manish"} age={20}/>
//         </div>
//     );
// };

// export default PropTypesComponent;

// ---------------------------------------------------------- prop types
import React, { Component } from 'react';
import PropTypes from 'prop-types';

class DemoComponent extends Component {
    render() {
        return (
            <div>
                <h2 className="text-info">Hello, {this.props.name}</h2>
                <h2 className="text-info">Age, {this.props.age}</h2>
            </div>
        );
    }

    static get propTypes() {
        return {
            name: PropTypes.string.isRequired,
            age: PropTypes.number.isRequired
        };
    }
}

const PropTypesComponent = () => {
    return (
        <div>
            {/* <DemoComponent /> */}
            {/* <DemoComponent name={"Manish"}/> */}
            <DemoComponent name={"Manish"} age={20}/>
            {/* <DemoComponent name={"Manish"} age={"10"}/> */}
        </div>
    );
};

export default PropTypesComponent;
